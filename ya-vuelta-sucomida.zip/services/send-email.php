<?php
include 'http-cors.php';

if (
    isset($_POST["r_name_lastname"]) && 
    isset($_POST["r_phone"]) && 
    isset($_POST["r_email"]) && 
    isset($_POST["r_place"]) &&
    isset($_POST["r_medio_plin"]) &&
    isset($_POST["r_medio_yape"]) &&
    isset($_POST["r_medio_efectivo"]) &&
    isset($_POST["r_product_price"]) &&
    isset($_POST["r_monto_ingresado"]) &&
    isset($_POST["r_monto_vuelto"]) ) {
         
        // Parametros HTTPS
        $name            = $_POST["r_name_lastname"];
        $phone           = $_POST["r_phone"];
        $email           = $_POST["r_email"];
        $place           = $_POST["r_place"];
        $plin            = $_POST["r_medio_plin"];
        $yape            = $_POST["r_medio_yape"];
        $efectivo        = $_POST["r_medio_efectivo"];
        $price           = $_POST["r_product_price"];
        $monto_ingresado = $_POST["r_monto_ingresado"];
        $monto_vuelto    = $_POST["r_monto_vuelto"];

        // Datos de Correo
        $header = "Enviado desde la web Ya Vuelta su Juane!";
        $emisor   = "rodnalcabello07@gmail.com";
        $receptor = $email;
        $asunto  = "Compra de Juanes";
        $mensaje = "Hola Rodnal";

        $email = mail($receptor, $asunto, $mensaje, $header);
        if($email){
            echo json_encode([
                'status' => 'ok', 
                'name' => $name, 
                'phone' => $phone, 
                'email' => $email, 
                'place' => $place, 
                'plin' => $plin, 
                'yape' => $yape, 
                'efectivo' => $efectivo, 
                'price' => $price, 
                'monto_ingresado' => $monto_ingresado,
                'monto_vuelto' => $monto_vuelto]);
        }else{
            echo json_encode([
                'status' => 'error']);
        }

        

        
            
}


